CONFIG = {
	locale: 'EN',
	developer: {
		debug: false,
		active: false,
		console: null
	},
	ajax: {
		proxy: 'http://nettv.mautilus.com/proxy/proxy.php?proxy_url={URL}'
	}
};